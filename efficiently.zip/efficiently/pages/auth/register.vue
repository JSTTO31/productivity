<template>
    <v-main class="d-flex align-center justify-center">
        <v-card width="450" class="pa-5">
            <v-text-field label="email"></v-text-field>
        </v-card>
    </v-main>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>