<template>
      <div>
      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Recusandae ex quis architecto ea quaerat excepturi consequatur nesciunt voluptatum sunt dolorem praesentium ipsa minima sit ipsum, deleniti, dolores nulla dolore! Itaque?
      </div>
</template>

<script setup lang="ts">
const route = useRoute()
</script>
  