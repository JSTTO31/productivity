<template>
    <v-container>
        <h2>
            {{ new Date().toDateString() }}
        </h2>
        <!-- <v-row>
            <v-col></v-col>
            <v-col cols="4">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro nostrum delectus, iste dolor doloremque hic at adipisci aut laudantium eius rerum debitis quaerat autem quod perspiciatis incidunt, ad itaque omnis.
            </v-col>
        </v-row> -->

    </v-container>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>