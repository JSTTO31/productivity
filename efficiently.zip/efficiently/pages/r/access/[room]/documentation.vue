<template>
    <v-main>
        <v-container>
            <v-row>
                <v-col cols="12">
                    <v-card class="rounded-lg" variant="tonal" color="primary" style="border: 2px dashed rgba(var(--v-theme-primary));" height="250px"></v-card>
                </v-col>
            </v-row>
        </v-container>
    </v-main>
    <v-navigation-drawer location="right">

    </v-navigation-drawer>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>