<template>
    <v-navigation-drawer color="transparent" width="100" location="right" class="border-0" expand-on-hover>
        
    </v-navigation-drawer>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>