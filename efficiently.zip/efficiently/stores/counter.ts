

export const useCounterStore = defineStore('counter', () => {
    const value = ref(1)


    return {value}
})


